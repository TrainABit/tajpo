import Foundation

struct OpenAIClient: LLMClient {
    let apiKey: String
    var model = "gpt-4.1-mini"
    var session: URLSession = .shared

    func rewrite(_ text: String, instruction: RewriteInstruction) async throws -> String {
        var request = URLRequest(url: URL(string: "https://api.openai.com/v1/responses")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(RequestBody(
            model: model,
            input: [
                .init(role: "system", content: instruction.prompt),
                .init(role: "user", content: text)
            ]
        ))

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            throw OpenAIError.requestFailed(String(data: data, encoding: .utf8) ?? "Unknown API error")
        }
        let decoded = try JSONDecoder().decode(ResponseBody.self, from: data)
        guard let output = decoded.output
            .flatMap(\.content)
            .first(where: { $0.type == "output_text" })?.text else { throw OpenAIError.emptyResponse }
        return output
    }
}

private struct RequestBody: Encodable {
    let model: String
    let input: [Message]
    struct Message: Encodable { let role: String; let content: String }
}

private struct ResponseBody: Decodable {
    let output: [Output]
    struct Output: Decodable { let content: [Content] }
    struct Content: Decodable { let type: String; let text: String? }
}

enum OpenAIError: LocalizedError {
    case requestFailed(String), emptyResponse
    var errorDescription: String? {
        switch self {
        case .requestFailed(let detail): "OpenAI request failed: \(detail)"
        case .emptyResponse: "OpenAI returned no text."
        }
    }
}
