import SwiftUI

struct SettingsView: View {
    @Bindable var appModel: AppModel
    @State private var apiKey = ""
    @State private var message = ""
    private let keyStore: APIKeyStoring = KeychainAPIKeyStore()

    var body: some View {
        Form {
            Section("OpenAI (BYOK)") {
                SecureField("API key", text: $apiKey)
                HStack {
                    Button("Save to Keychain") { save() }
                    Button("Remove", role: .destructive) { remove() }
                }
                Text(message).font(.caption).foregroundStyle(.secondary)
            }
            Section("Shortcut") {
                LabeledContent("Rewrite selection", value: "⌥⌘T")
                Text("Editable shortcut recording comes next.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Privacy") {
                Text("Selected text is sent only to OpenAI using your API key. Tajpo has no backend and does not log text.")
            }
        }
        .padding(20)
        .frame(width: 460)
    }

    private func save() {
        do { try keyStore.save(apiKey); apiKey = ""; message = "Saved in Keychain." }
        catch { message = error.localizedDescription }
    }

    private func remove() {
        do { try keyStore.delete(); apiKey = ""; message = "Removed." }
        catch { message = error.localizedDescription }
    }
}
