# Tajpo

A private, native macOS writing tool. Select text anywhere, press a global hotkey, and Tajpo improves or rewrites it in place.

## Privacy promise

- No Tajpo account and no Tajpo backend are required for the MVP.
- Text stays on the Mac except for the API request made directly to the provider chosen by the user.
- The OpenAI API key is BYOK and stored in Keychain, never in UserDefaults or the repository.
- A local provider (MLX or llama.cpp) can implement the same `LLMClient` interface later.
- No analytics or text logging by default.

## MVP scope

1. Menu bar app with settings.
2. User-configurable global hotkey.
3. Read selected text through macOS Accessibility APIs.
4. Rewrite through the user's OpenAI API key.
5. Replace the selection while preserving the clipboard where possible.
6. Clear permission, error, and progress states.

Out of scope for the first milestone: accounts, cloud sync, subscriptions, team features, prompt marketplace, and a hosted backend.

## Architecture

- `App/`: SwiftUI entry point and composition root.
- `Core/Hotkey/`: global shortcut registration behind a protocol.
- `Core/Text/`: selection capture and replacement boundary.
- `Features/Rewrite/`: rewrite use case and UI-facing state.
- `Infrastructure/LLM/`: provider-neutral client plus OpenAI BYOK implementation.
- `Infrastructure/Security/`: Keychain access.
- `Settings/`: preferences UI and persisted non-secret settings.

The core flow depends on protocols, so OpenAI can be swapped for a local model without changing the rewrite feature.

## Run

Requires macOS 14+ and Xcode 16 / Swift 6.

```bash
swift build
swift run Tajpo
```

Grant Accessibility permission when macOS asks. Add the OpenAI API key in Settings. The current skeleton wires the boundaries and UI; selection replacement and editable shortcut recording are the next implementation steps.
