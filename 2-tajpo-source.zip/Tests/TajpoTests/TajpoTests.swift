import Testing
@testable import Tajpo

@Test func improveInstructionRequiresTextOnly() {
    #expect(RewriteInstruction.improve.prompt.contains("Return only"))
}
